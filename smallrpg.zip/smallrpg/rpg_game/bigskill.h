#ifndef BIGSKILL_H
#define BIGSKILL_H
#include <feibiao.h>
#include <QImage>
class bigskill:public feibiao{
public:void show(QPainter &p);
    bigskill(){used=false;}//初始状态：这个技能不在使用中
    bigskill(int x,int y);//会确定技能释放的初始位置的构造函数
    int get_ss(){//这个是为了得到ss的值
        return ss;
    }
    void starts(){//技能释放开始
        ss=1;
    }
protected:
    QImage pic[4][4];//四个方向，一个方向技能随着释放会有四种形态变化，一共需要十六张图片
    static int ss;//记录现在技能的释放状态的变量
};

#endif // BIGSKILL_H
