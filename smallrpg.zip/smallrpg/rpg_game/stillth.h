#ifndef STILLTH_H
#define STILLTH_H
#include <QPainter>
#include <maps.h>
#include "object.h"
const int size=32;
class stillth:public object{
    friend class maps;
public:stillth(){
        x=0;//默认截取图片（0，0）点1*1游戏坐标的图（采用的素材图片此点为空，即什么也不显示）
        y=0;
        len=1;
        wid=1;
        coverable=true;
        eatable=true;
        usable=false;
    }
    stillth(int x,int y,int len,int wid):x(x),y(y),len(len),wid(wid){
        coverable=true;
        eatable=true;
        usable=false;
    }
    void sets(int x=0,int y=0,int len=1,int wid=1){
        this->x=x;
        this->y=y;
        this->len=len;
        this->wid=wid;
        QImage map;
        map.load("MAP.png");
        part=map.copy(x*size,y*size,len*size,wid*size);
        usable=true;//一旦放置有物体，这个点即为使用
    }
    void show(QPainter &paint,int setx,int sety){
        paint.drawImage(setx*size,sety*size,part);
    }
    int getx(){
        return x;
    }
    int gety(){
        return y;
    }
    bool getcover(){
        return coverable;
    }
    bool geteat(){
        return eatable;
    }
    bool getuse(){
        return usable;
    }

    bool getbld(){
        if(eatable==1)
        return true;
        else return false;
    }
    bool getpow(){
        if(eatable==2)
        return true;
        else return false;
    }
protected:
    int x;
    int y;
    int len;
    int wid;
    int setx;
    int sety;
    QImage part;
};

#endif // STILLTH_H
