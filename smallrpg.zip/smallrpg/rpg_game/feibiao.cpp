#include "feibiao.h"
#include "maps.h"
feibiao::feibiao(int x, int y){
    used=false;
    this->xx=x;
    this->yy=y;
    x0 = x;
    y0 = y;
    s=0;
    a.load("feibiao.png");
}
void feibiao::dire(int i){
    this->direction=i;
}
void feibiao::show(QPainter &p){
    if(s>0){
        int i=this->direction;
        s++;
        if(i==4){
            yy-=v;
        }else if(i==1){
            yy+=v;
        }else if(i==2){
            xx-=v;
        }else if(i==3){
            xx+=v;
        }
    }
    if(s>qsize) {
        s=0;
    }
    if(s==0) {
        used=true;
    }
    p.drawImage(xx,yy,a);
}
