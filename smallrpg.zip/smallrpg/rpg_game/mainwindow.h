#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <fstream>
#include <QMainWindow>
#include <QTimer>
#include <iostream>
#include "player.h"
#include "autoplayer.h"
#include "maps.h"
#include "feibiao.h"
#include "kuwu.h"
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    void paintEvent(QPaintEvent *);
    void keyPressEvent(QKeyEvent *event);
    ~MainWindow();
protected slots:
    void automan();
    void add();
private:
    Ui::MainWindow *ui;
    player p1;//玩家人物
    vector<autoplayer>p;//用来产生敌方人物
    QTimer *tim,*addp;//两个计时器
    maps m;//地图类
    bool start=false;//游戏开始
    bool end=false;//游戏胜利结束
};
#endif // MAINWINDOW_H
