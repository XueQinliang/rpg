#include "mainwindow.h"
#include <QApplication>
#include <QMessageBox>
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();
    QMessageBox message(QMessageBox::NoIcon, "游戏背景", "假扮风影的大蛇丸\n即将袭击村子刺杀三代\n你，漩涡鸣人，要打败大蛇丸\n但大蛇丸最近学会了分身术\n如果你不能消灭他的所有分身\n他就会源源不断地产生分身\n（提示：WSAD表示上下左右\nJ为普通攻击\nK为法术攻击\n碰到松树和白色的地刺会受伤\n快去完成你的任务吧)\n这可是S级任务，一定小心");
    message.setIconPixmap(QPixmap("dashewan.png"));
    message.exec();
    return a.exec();
}

