#include "shenbiao.h"
int shenbiao::sss=0;
shenbiao::shenbiao(int x, int y){
    used=false;
    this->xx=x;
    this->yy=y;
    x0 = x;
    y0 = y;
    sss=0;
    a.load("feibiao2.png");
}
void shenbiao::show(QPainter &p,int x,int y){
    if(get_sss()<=250&&get_sss()>0)sss++;
    if(used==true){
    int x1=x-xx;
    int y1=y-yy;
    if(x1>0) xx++;
    if(x1<0) xx--;
    if(y1>0) yy++;
    if(y1<0) yy--;
    p.drawImage(xx,yy,a);
    if(abs(x1)<=4&&abs(y1)<=4){
        used=false;
        sss=0;
    }
    if(get_sss()>250){
       sss=1;
    }
}
}

