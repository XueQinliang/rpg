#include "bigskill.h"
#include "maps.h"
#include "QImage"
int bigskill::ss=0;
bigskill::bigskill(int x,int y){
    used=false;
    this->xx=x;
    this->yy=y;
    x0=xx;
    y0=yy;
    ss=0;
    QImage all[4];
    all[0].load("luoxuand.png");
    all[1].load("luoxuanl.png");
    all[2].load("luoxuanr.png");
    all[3].load("luoxuanu.png");
    for(int i=0;i<4;i++){
        pic[0][i]=all[0].copy(QRect(i*2*qsize,0,1*qsize,2*qsize));
        pic[3][i]=all[3].copy(QRect(i*2*qsize,0,1*qsize,2*qsize));
        pic[1][i]=all[1].copy(QRect(i*1*qsize,0,1*qsize,2*qsize));
        pic[2][i]=all[2].copy(QRect(i*1*qsize,0,1*qsize,2*qsize));
    }
}
void bigskill::show(QPainter &p){
    int i=this->direction;

    if(ss<qsize&&ss>0){
        ss++;
        if(i==4){
            yy-=v;
            p.drawImage(xx,yy,pic[3][(int)floor((ss-1)*4.0/qsize)]);
        }else if(i==1){
            yy+=v;
            p.drawImage(xx,yy,pic[0][(int)floor(ss*4.0/qsize)]);
        }else if(i==2){
            xx-=v;
            p.drawImage(xx,yy,pic[1][(int)floor(ss*4.0/qsize)]);
        }else if(i==3){
            xx+=v;
            p.drawImage(xx,yy,pic[2][(int)floor(ss*4.0/qsize)]);
        }
    if(ss>=qsize) {
        ss=0;
    }
    if(ss==0) {
        used=true;
    }
    }
}
