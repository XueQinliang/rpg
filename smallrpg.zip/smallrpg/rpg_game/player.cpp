#include <iostream>
#include <QPainter>
#include <string>
#include "player.h"
#include "windows.h"
#include "maps.h"
#include <time.h>
#include "mainwindow.h"
using namespace std;
void player::move(int i,maps &m,int v){
    action++;
    if(action>=16){
        action=1;
    }
    if(cover(i,m)){
        if(die(i,m)) {
            if(wound==0)
            if(blood>5)
            blood=blood-5;
            else blood=0;
            if(i%2==0)
            wound=1;
            else wound=-1;
        }
    if(wound==0){
    if(i==1) {y-=v;
        state=4;}
    else if(i==2) {y+=v;
        state=1;}
    else if(i==3) {x-=v;
        state=2;}
    else if(i==4) {x+=v;
        state=3;}
    else {}}}
    else if(cover(i,m)==false&&eat(i,m)!=0){
        if(eat(i,m)==1){
        if(fullblood-blood>5)
            blood+=5;
        else blood=fullblood;}
        else if(eat(i,m)==2){
            if(fullpower-power>5)
                power+=5;
            else power=fullpower;}
        if(i==1) {
            m.th[(int)floor(x*1.0/qsize+0.5)][(int)floor(y*1.0/qsize+0.5)].sets(0,0);
            m.th[(int)floor(x*1.0/qsize+0.5)][(int)floor(y*1.0/qsize+0.5)].set(true,true);
            y-=v;
            state=4;}
        else if(i==2) {
            m.th[(int)floor(x*1.0/qsize+0.5)][(int)floor(y*1.0/qsize+0.5)+2].sets(0,0);
            m.th[(int)floor(x*1.0/qsize+0.5)][(int)floor(y*1.0/qsize+0.5)+2].set(true,true);
            y+=v;
            state=1;}
        else if(i==3) {
            m.th[(int)floor(x*1.0/qsize+0.5)-1][(int)floor(y*1.0/qsize+0.5)+1].sets(0,0);
            m.th[(int)floor(x*1.0/qsize+0.5)-1][(int)floor(y*1.0/qsize+0.5)+1].set(true,true);
            x-=v;
            state=2;}
        else if(i==4) {
            m.th[(int)floor(x*1.0/qsize+0.5)+1][(int)floor(y*1.0/qsize+0.5)+1].sets(0,0);
            m.th[(int)floor(x*1.0/qsize+0.5)+1][(int)floor(y*1.0/qsize+0.5)+1].set(true,true);
            x+=v;
            state=3;}
        else {}
    }
}
void player::show(QPainter &paint,maps &m){
        string route="";
        route=route+name;
        route=route+".png";
        const char *p=route.data();
        all.load(p);//通过输入的人物名字加载图片
        for(int i=0;i<4;i++){
            for(int j=0;j<4;j++){
                play[i][j]=all.copy(QRect(i*qsize,j*2*qsize,qsize,qsize*2));
            }//行走中不同方向和时刻人物图片不同来实现人物动态的效果
        }
        if(wound==0){
            if(fight()==true) action = 7;
            paint.drawImage(x, y, play[action/4][state-1]);
        }
        else {
            QImage part;
            string r="wound";
            char s=abs(wound)/10+49;
            if(wound>0)
            r=r+s;
            if(wound<0){
                r=r+"-";
                r=r+s;
            }
            r=r+".png";
            const char *p=r.data();
            part.load(p);
            if(blood>0){
            paint.drawImage(x,y,part);
            if(cover((int)(3.5+0.5*wound/abs(wound)),m)){
            set(x-wound/10,y);}else set(x+wound/10,y);
            if(wound>0)wound+=2;
            if(wound<0)wound-=2;
            if(abs(wound)==29){
            wound=0;
            }}else{
                if(abs(wound)<=29)
                paint.drawImage(x,y,part);
                else
                paint.drawImage(x,y+qsize,part);
                if(cover((int)(3.5+0.5*wound/abs(wound)),m)){
                set(x-wound/10,y);}else set(x+wound/10,y);
                if(abs(wound)<=50){
                    if(wound>0)wound+=2;
                    if(wound<0)wound-=2;
                }

        }}
            paint.setPen(QPen(Qt::black,1));//画人物上面的经验条、血条、蓝条
            paint.drawRect(x,y-6,35,6);
            paint.drawRect(x,y-15,35,6);
            paint.drawRect(x,y+3,35,6);
            paint.setBrush(Qt::blue);
            paint.drawRect(x,y-6,35*power/fullpower,6);
            paint.setBrush(Qt::red);
            paint.drawRect(x,y-15,35*blood/fullblood,6);
            paint.setBrush(Qt::yellow);
            paint.drawRect(x,y+3,35*exp/fullexp,6);
            paint.setBrush(Qt::NoBrush);
            memory();
            vector<feibiao>::iterator it;
            for(it=this->feis.begin();it!=this->feis.end();it++){
                (*it).show(paint);
            }
            for(it=this->feis.begin();it!=this->feis.end();){
            if((*it).used==true){
                it=feis.erase(it);
            }
            else ++it;
            }
            if(bo.used==true){
                bigskill boo;
                bo=boo;
            }
            bo.show(paint);
    }
bool player::cover(int i,maps &m){//检验前方物体可否覆盖
   if(i==1){
       if(m.th[(int)floor(x*1.0/qsize+0.5)][(int)floor(y*1.0/qsize+1)].getcover()==false) return false;
       else return true;
   }else if(i==2){
       if(m.th[(int)floor(x*1.0/qsize+0.5)][(int)floor(y*1.0/qsize+0.75)+1].getcover()==false) return false;
       else return true;
   }else if(i==3){
       if(m.th[(int)floor(x*1.0/qsize+0.25)][(int)floor(y*1.0/qsize+0.5)+1].getcover()==false) return false;
       else return true;
   }else if(i==4){
       if(m.th[(int)floor(x*1.0/qsize)+1][(int)floor(y*1.0/qsize+0.5)+1].getcover()==false) return false;
       else return true;
   }
}


int player::eat(int i,maps &m){//检验前方物体可否吃
   if(i==1){
       if(m.th[(int)floor(x*1.0/qsize+0.5)][(int)floor(y*1.0/qsize+1)].getbld()==true) return 1;
       else if(m.th[(int)floor(x*1.0/qsize+0.5)][(int)floor(y*1.0/qsize+1)].getpow()==true) return 2;
       else return 0;
   }else if(i==2){
       if(m.th[(int)floor(x*1.0/qsize+0.5)][(int)floor(y*1.0/qsize+0.75)+1].getbld()==true) return 1;
       else if(m.th[(int)floor(x*1.0/qsize+0.5)][(int)floor(y*1.0/qsize+0.75)+1].getpow()==true) return 2;
       else return 0;
   }else if(i==3){
       if(m.th[(int)floor(x*1.0/qsize+0.25)][(int)floor(y*1.0/qsize+0.5)+1].getbld()==true) return 1;
       else if(m.th[(int)floor(x*1.0/qsize+0.25)][(int)floor(y*1.0/qsize+0.5)+1].getpow()==true) return 2;
       else return 0;
   }else if(i==4){
       if(m.th[(int)floor(x*1.0/qsize)+1][(int)floor(y*1.0/qsize+0.5)+1].getbld()==true) return 1;
       else if(m.th[(int)floor(x*1.0/qsize)+1][(int)floor(y*1.0/qsize+0.5)+1].getpow()==true) return 2;
       else return 0;
   }
}
bool player::die(int i,maps &m){//如果物体可覆盖但不可吃则减血
    return cover(i,m)&&(eat(i,m)==false);
}
void player::attacks(int i){//攻击的函数会产生一个飞镖
    feibiao fei(x,y);
    fei.dire(i);
    fei.setv(5);
    fei.start();
    this->feis.push_back(fei);
}

void player::skill(int i){//技能的函数会产生一个技能波
    if(bo.get_ss()==0&&getpower()>0){
    power-=5;
    bigskill b(x,y);
    bo=b;
    bo.dire(i);
    bo.setv(20);
    bo.starts();
    }
}
bool player::check(kuwu f){
    if(f.getx()+12>=this->getx()&&f.getx()+12<=this->getx()+qsize
            &&f.gety()+12>=this->gety()&&f.gety()+12<=this->gety()+qsize&&wound==0){
        while(wound==0){
            wound=rand()%3-1;
        }
        blood-=5;
        return true;
    }else return false;
}
bool player::check(shenbiao s){
    if(abs(s.getx()-this->getx())<=4&&abs(s.gety()-this->gety())<=4&&wound==0){
        blood-=5;
        return true;
    }else return false;
}
void player::memory(){
    ofstream file;
    file.open("data.txt", ios::out);
    file<<this->rank<<','<<this->exp;
    fullblood=35+rank*10;
    fullpower=35+rank*10;
    file.close();
}
void player::read(){
    FILE *re;
    re=fopen("data.txt","r");
    char info[10];
    char ra[5];
    char ex[5];
    fgets(info,10,re);
    info[strlen(info)]='\0';
    for(int i=0;i<strlen(info);i++){
        if(info[i]!=',') ra[i]=info[i];
        if(info[i]==',') {
            ra[i]='\0';
            strcpy(ex,info+i+1);
            break;
    }}
    this->rank=atoi(ra);
    fullexp+=rank*10;
    this->exp=atoi(ex);
}
void player::showinfo(QPainter &paint){
    QImage info;
    info.load("juanzhou1.png");
    paint.drawImage(0,-2*qsize,info);
    QFont font;
    font.setPointSize(10);
    font.setFamily("Bernard MT Condensed");
    font.setLetterSpacing(QFont::AbsoluteSpacing,0);
    paint.setFont(font);
    paint.drawText(QPoint(70,22-2*qsize),"HP");
    paint.drawRect(90,12-2*qsize,80,10);
    paint.drawText(QPoint(70,37-2*qsize),"MP");
    paint.drawRect(90,27-2*qsize,80,10);
    paint.drawText(QPoint(70,52-2*qsize),"ETC");
    paint.drawRect(90,42-2*qsize,80,10);
    paint.setBrush(Qt::red);
    paint.drawRect(90,12-2*qsize,80*blood/fullblood,10);
    paint.setBrush(Qt::blue);
    paint.drawRect(90,27-2*qsize,80*power/fullpower,10);
    paint.setBrush(Qt::yellow);
    paint.drawRect(90,42-2*qsize,80*exp/fullexp,10);
    paint.setBrush(Qt::green);
    paint.drawEllipse(15,5-2*qsize,16,16);
    paint.setBrush(Qt::NoBrush);
    font.setPointSize(8);
    paint.setFont(font);
    char str[10],m[5];
    itoa(getblood(),str,10);
    itoa(getfullb(),m,10);
    strcat(str,"/");
    strcat(str,m);
    paint.drawText(QPoint(130-strlen(str)*2,22-2*qsize),str);
    itoa(getpower(),str,10);
    itoa(getfullp(),m,10);
    strcat(str,"/");
    strcat(str,m);
    paint.drawText(QPoint(130-strlen(str)*2,37-2*qsize),str);
    itoa(getexp(),str,10);
    itoa(getfulle(),m,10);
    strcat(str,"/");
    strcat(str,m);
    paint.drawText(QPoint(130-strlen(str)*2,52-2*qsize),str);
    itoa(rank,str,10);
    font.setPointSize(12);
    paint.setFont(font);
    paint.drawText(QPoint(15+8-strlen(str)*4,20-2*qsize),str);
}
