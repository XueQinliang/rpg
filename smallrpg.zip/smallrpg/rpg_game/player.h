#ifndef PLAYER_H
#define PLAYER_H
#include <iostream>
#include <QImage>
#include <QPainter>
#include "object.h"
#include "maps.h"
#include "feibiao.h"
#include "bigskill.h"
#include "shenbiao.h"
#include "kuwu.h"
using namespace std;
class player:public object{
public:
    player(){
        read();//从保存的文件里读入等级和经验值
        this->eatable=false;
        this->coverable=false;
    }
    player(int x,int y,int state,int action):x(x),y(y),state(state),action(action){
        read();
        this->eatable=false;
        this->coverable=false;
    }
    void getbp(){//初始化人物当前等级下的血量和魔量
        fullblood=35+rank*10;
        fullpower=35+rank*10;
        blood=fullblood;
        power=fullpower;
    }
    void set(int x,int y,int state=1,int action=1){//设置人物位置和方向
        this->x=x;
        this->y=y;
        this->state=state;
        this->action=action;
    }
    bool check(kuwu f);//检测敌方苦无（一种飞镖）
    bool check(shenbiao s);//检测敌方神镖（自动追踪飞镖）
    void move(int i,maps &m,int v);
    void show(QPainter &paint,maps &m);
    void attacks(int i);//玩家普通攻击
    void skill(int i);//玩家技能攻击
    int getx(){return x;}//得到人物当前位置
    int gety(){return y;}//得到人物当前位置
    void death(){
       wound=0;
       blood=0;
    }//判断是否死亡
    int getexp(){return exp;}//得到当前经验值
    void addexp(int i){exp+=i;}//杀死敌方人物获得经验
    int getrank(){//获得当前人物等级
        return rank;
    }
    void addrank(){//如果经验值达到当前等级满经验值则升级
        if(exp>=fullexp){
            exp=0;
            rank++;
            fullexp+=rank*10;
            fullblood=35+rank*10;
            fullpower=35+rank*10;
            blood=fullblood;
            power=fullpower;
        }
    }
    int direction(){//获得人物当前前进方向
        return state;
    }
    int getblood(){return blood;}
    int getpower(){return power;}
    int getfullb(){return fullblood;}
    int getfullp(){return fullpower;}
    int getfulle(){return fullexp;}
    void wound0(){wound=0;}//回复人物正常状态
    bool falldown(){//检测人物摔倒的动作是否完成即是否可以宣告死亡
        return abs(wound)>=50;
    }
    void setname(string n){//设置人物姓名以决定之后人物显示的是敌方形象还是我方形象
        name=n;
    }
    int eat(int i,maps &m);//判断可吃
    bool cover(int i,maps &m);//判断可覆盖
    bool die(int i,maps &m);//判断是否触碰到受伤减血的东西
    bool fight(){//判断是否处于战斗状态的函数
       if(bo.get_ss()==0){
           return false;
       }else return true;
    }
    void showinfo(QPainter &paint);//用来展示人物现在信息的函数
    vector<feibiao>feis;//飞镖的vector
    bigskill bo;//法术攻击波的一个对象
protected:
    int x;
    int y;
    int fullblood=35;//初始体力35
    int fullpower=35;//初始法力35
    int state;
    int action;
    int blood;
    int power;
    int exp=0;
    int fullexp=35;
    int rank=0;
    int wound=0;
    string name;
    QImage all;//用来传入人的各形态的对象
    QImage play[4][4];//用来截取人物不同形态

private:
    void memory();//将人物现在的等级和经验写入文件的函数
    void read();//将人物存在文件中的等级和经验读出来的函数
};
#endif
