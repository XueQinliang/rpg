#ifndef FEIBIAO_H
#define FEIBIAO_H
#include <QPainter>
class feibiao{
public:feibiao(){used=false;}//初始状态为未使用
    feibiao(int x,int y);//确定初始位置的构造函数
    int get_s(){//记录飞镖的释放状态
        return s;
    }
    void start(){//开始释放
        s=1;
    }
    void setv(int i){//设置飞镖的移动速度
        v=i;
    }
    void set(int x,int y){//重设飞镖的位置
        this->xx=x;
        this->yy=y;
    }
    void dire(int i);//确定飞镖飞行的方向
    void show(QPainter &p);
    int getx(){//得到坐标xx
        return xx;
    }
    int gety(){//得到坐标yy
        return yy;
    }
    bool used;//是否被使用
    ~feibiao(){}
protected:int xx,yy,x0,y0;
    int direction;
    int v;
    friend class player;
    int s=0;
    QImage a;
};
#endif // FEIBIAO_H
