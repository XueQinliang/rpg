#ifndef AUTOPLAYER_H
#define AUTOPLAYER_H
#include "maps.h"
#include "player.h"
#include "kuwu.h"
#include "bigskill.h"
#include "shenbiao.h"
//这个类是电脑自动人物即敌方人物的类，继承自player类
class autoplayer:public player{
    public:
    autoplayer(){
        fullblood=35;
        blood=fullblood;
    }//满血设置为35，初始状态为满血
    void move(int i,maps &m,int v);//控制自动人物移动
    void show(QPainter &paint, maps &m);//画出自动人物
    void bigattack();//自动人物释放较强攻击
    void attack();//自动人物释放一般攻击
    bool check(feibiao f);//检测飞镖攻击
    bool check(bigskill b);//检测技能攻击
    kuwu fe[4];//人物有四支苦无（一种飞镖）
    vector<shenbiao>shens;//一个神镖（游戏中设置为可追踪飞镖）的vector
private:
    int fullblood;//满血量
};

#endif // AUTOPLAYER_H
