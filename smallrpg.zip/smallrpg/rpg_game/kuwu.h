#ifndef KUWU_H
#define KUWU_H
#include "feibiao.h"
class kuwu:public feibiao{
public:kuwu(){used=false;}//这个类与飞镖类基本相同，只是加载的图片不同
    kuwu(int x, int y,int d){
        used=false;
        this->xx=x;
        this->yy=y;
        this->dd=d;
        x0 = x;
        y0 = y;
        s=0;
        if(dd==1)
        a.load("kuwud.png");//四个方向的苦无图片加载进来
        if(dd==2)
        a.load("kuwul.png");
        if(dd==3)
        a.load("kuwur.png");
        if(dd==4)
        a.load("kuwuu.png");
    }
protected:int dd;//dd表示方向
};

#endif // KUWU_H
