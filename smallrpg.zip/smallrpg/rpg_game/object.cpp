#include "object.h"
maps object::map
