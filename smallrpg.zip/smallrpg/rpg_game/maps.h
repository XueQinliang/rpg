#ifndef MAP_H
#define MAP_H
#include "stillth.h"
#include "QPainter"
#include "QImage"
#include <string>
#include <fstream>
const int qsize=32;
class maps{
    friend class player;//玩家为maps的友元，可以调用maps的私有和保护成员
    protected:
    struct things{
        //这个结构体用来保存所用物体的信息，
        //前两个数表示从素材图片上截取的位置；
        //中间两个表示大小，最后两个表示可吃与可覆盖
        //可吃分两种，1表示吃完补血，2表示吃完补魔
        int stone1[6]={4,9,1,1,0,0};
        int stone2[6]={5,9,1,1,0,0};
        int tree1[6]={6,4,2,2,0,0};
        int tree2[6]={0,9,2,2,0,1};
        int trees[6]={2,8,2,2,0,0};
        int wood1[6]={2,13,1,2,0,0};
        int wood2[6]={1,15,2,1,0,0};
        int bucket[6]={14,0,1,1,0,0};
        int tree3[6]={5,6,1,2,0,0};
        int dici[6]={8,11,1,1,0,1};
        int fruit[6]={10,13,1,1,1,0};
        int red[6]={0,2,1,1,1,0};
        int blue[6]={1,3,1,1,2,0};
    }thing;
    stillth th[14][12];//这里有一个静物的对象二位数组，用来放置地图上的对象
public:
    void setmaps();//设置整个地图
    void setmap(int x,int y,int *p);//设置单个物体
    void show(QPainter &paint);//展示地图
    int *pair(char *str);//将地图文件读入的东西与相应的数组建立联系
    bool beset(int x,int y);//判断这个点是否放置有物体
};

#endif // MAP_H
