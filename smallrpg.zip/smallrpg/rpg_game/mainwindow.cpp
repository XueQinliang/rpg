#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPainter>
#include "maps.h"
#include "stillth.h"
#include <QPaintEvent>
#include <time.h>
#include "player.h"
#include <vector>
#include <QFont>
#include <QMessageBox>
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setWindowTitle("鸣人VS大蛇丸");
    this->resize(QSize(14*qsize,14*qsize));
    m.setmaps();
    int rx,ry;
    srand((unsigned)time(NULL));
    do{
        rx=rand()%12+1;
        ry=rand()%9+1;
    }while(m.beset(rx,ry)==false);
    p1.set(qsize*rx,qsize*ry);
    p1.getbp();
    p1.setname("Naruto");
    do{
        rx=rand()%12+1;
        ry=rand()%9+1;
    }while(m.beset(rx,ry)==false);
    autoplayer p2,p3,p4,p5;
    p2.set(rx*qsize,ry*qsize);
    p2.setname("fengying");
    do{
        rx=rand()%12+1;
        ry=rand()%9+1;
    }while(m.beset(rx,ry)==false);
    p3.set(rx*qsize,ry*qsize);
    p3.setname("fengying");
    p.push_back(p2);
    p.push_back(p3);
    addp=new QTimer(this);
    connect(addp,SIGNAL(timeout()),this,SLOT(add()));
    addp->start(10000);
    addp->setInterval(10000);
    tim=new QTimer(this);
    connect(tim,SIGNAL(timeout()),this,SLOT(automan()));
    tim->start(20);
    tim->setInterval(20);

}
void MainWindow::add(){
    autoplayer pi;
    int rx,ry;
    do{
        rx=rand()%12+1;
        ry=rand()%9+1;
    }while(m.beset(rx,ry)==false);
    pi.set(rx*qsize,ry*qsize);
    pi.setname("fengying");
    do{
        rx=rand()%12+1;
        ry=rand()%9+1;
    }while(m.beset(rx,ry)==false);
    int red[6]={0,2,1,1,1,0};
    int blue[6]={1,3,1,1,2,0};
    do{
        rx=rand()%12+1;
        ry=rand()%9+1;
    }while(m.beset(rx,ry)==false);
    m.setmap(rx,ry,red);
    do{
        rx=rand()%12+1;
        ry=rand()%9+1;
    }while(m.beset(rx,ry)==false);
    m.setmap(rx,ry,blue);
    if(p.size()<10&&start==true&&end==false)
    p.push_back(pi);

}
void MainWindow::automan(){
    static int num=0;
    num++;
    if(num>2000){
        num=0;
    }
    if(start==true){//方向和攻击随机
            static int n=0;
            n++;
            srand((unsigned)time(NULL));
            static int nu[2][10]={1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1};
            for(int i=0;i<p.size();i++){
            nu[0][i]=rand();
            if(num%1000==i*250)
                p[i].bigattack();
            if(nu[0][i]%10==0){
                p[i].attack();
            }if(n>rand()%100+50){
                nu[1][i]=rand()%4+1;
                n=0;
            }
            if(p[i].cover(nu[1][i],m)&&p[i].eat(nu[1][i],m))
                p[i].move(nu[1][i],m,1);
            else nu[1][i]=rand()%4+1;
            }
            repaint();
}
}
void MainWindow::paintEvent(QPaintEvent *){
    QPainter paint(this);
    paint.translate(0,2*qsize);
    if(start==false){//如果没开始就加载标题页面
        QImage pic;
        pic.load("biaoti.jpg");
        paint.drawImage(0,-2*qsize,pic);
    }
    else{
    QImage bei;
    bei.load("grass.jpg");//背景图片
    paint.drawImage(0,-2*qsize,bei);
    m.show(paint);
    if(p1.getblood()>0||p1.falldown()!=true)
    p1.show(paint,m);
    for(int i=0;i<p.size();i++){
    vector<shenbiao>::iterator h;
    for(h=this->p[i].shens.begin();h!=this->p[i].shens.end();h++){
        p1.check(*h);
    }
    for(int ii=0;ii<4;ii++)p1.check(p[i].fe[ii]);
    vector<shenbiao>::iterator iter;
    for(iter=p[i].shens.begin();iter!=p[i].shens.end();iter++){
        if((*iter).used==true){
            (*iter).show(paint,p1.getx(),p1.gety());
        }
    }
    for(iter=this->p[i].shens.begin();iter!=this->p[i].shens.end();){
       if((*iter).used==false){
           iter=p[i].shens.erase(iter);
       }
       else ++iter;
    }
    vector<feibiao>::iterator it;
    p[i].show(paint,m);
    for(it=this->p1.feis.begin();it!=this->p1.feis.end();it++){
        p[i].check(*it);
    }
    p[i].check(p1.bo);
    if(p[i].falldown())p1.addexp(5);}
    for(int i=0;i<p.size();i++){
    if(p[i].getblood()<=0&&(p[i].falldown())){
        vector<autoplayer>::iterator de;
        de=p.begin()+i;
        p.erase(de);
        break;
    }}
    p1.addrank();
    if(p1.getblood()<=0&&p1.falldown()){
        QImage over;
        over.load("gameover.jpg");//游戏死亡图片
        paint.drawImage(0,150,over);
    }
    p1.showinfo(paint);
    if(p.size()==0) {
        end=true;
        QImage pend;
        pend.load("end.jpg");//游戏胜利结束图片
        paint.drawImage(0,-2*qsize,pend);
    }
}
}
void MainWindow::keyPressEvent(QKeyEvent *event){
    if(event->key()==Qt::Key_Y) start=true;
    if(event->key()==Qt::Key_W) p1.move(1,m,5);
    if(event->key()==Qt::Key_S) p1.move(2,m,5);
    if(event->key()==Qt::Key_A) p1.move(3,m,5);
    if(event->key()==Qt::Key_D) p1.move(4,m,5);
    if(event->key()==Qt::Key_J) p1.attacks(p1.direction());
    if(event->key()==Qt::Key_K) p1.skill(p1.direction());
    if(event->key()==Qt::Key_T&&end==true){
        m.setmaps();
        int rx,ry;
        srand((unsigned)time(NULL));
        do{
            rx=rand()%12+1;
            ry=rand()%9+1;
        }while(m.beset(rx,ry)==false);
        p1.set(qsize*rx,qsize*ry);
        p1.getbp();
        p1.wound0();
        p1.setname("Naruto");
        do{
            rx=rand()%12+1;
            ry=rand()%9+1;
        }while(m.beset(rx,ry)==false);
        autoplayer p2,p3,p4,p5;
        p2.set(rx*qsize,ry*qsize);
        p2.setname("fengying");
        do{
            rx=rand()%12+1;
            ry=rand()%9+1;
        }while(m.beset(rx,ry)==false);
        p3.set(rx*qsize,ry*qsize);
        p3.setname("fengying");
        p.empty();
        p.push_back(p2);
        p.push_back(p3);
        end=false;
    }
    if((p1.getblood()<=0)&&event->key()==Qt::Key_R) {
        int rx,ry;
        srand((unsigned)time(NULL));
        do{
            rx=rand()%12+1;
            ry=rand()%9+1;
        }while(m.beset(rx,ry)==false);
        p1.set(qsize*rx,qsize*ry);
        p1.setname("Naruto");
        p1.getbp();
        p1.wound0();
        autoplayer p2,p3;
        for(int i=0;i<p.size();i++){
        do{
            rx=rand()%12+1;
            ry=rand()%9+1;
        }while(m.beset(rx,ry)==false);
        p2.set(rx*qsize,ry*qsize);
        p2.setname("fengying");
        do{
            rx=rand()%12+1;
            ry=rand()%9+1;
        }while(m.beset(rx,ry)==false);
        p3.set(rx*qsize,ry*qsize);
        p3.setname("fengying");
        }
        this->p[0]=p2;
        this->p[1]=p3;
        for(int i=p.size();i>2;i--){
            vector<autoplayer>::iterator de;
            de=p.begin()+i;
            p.erase(de);
        }
        maps newm;
        newm.setmaps();
        m=newm;
        if(end==true){
            start=true;
            end=false;
        }
    }
    this->repaint();
}

MainWindow::~MainWindow()
{
    delete ui;
}
