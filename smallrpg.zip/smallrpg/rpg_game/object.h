#ifndef OBJECT_H
#define OBJECT_H
#include <QPainter>
class object{//所有物体和所有人的基类
public:object(){}
    object(int x,int y,int eatable,bool coverable):x(x),y(y){
        this->eatable=eatable;
        this->coverable=coverable;
    }
    void set(int x,int y,int eatable,bool coverable){//重新设置一些基本性质
        this->x=x;
        this->y=y;
        this->eatable=eatable;
        this->coverable=coverable;
    }
    void set(int eatable,bool coverable){//重载函数
        this->eatable=eatable;
        this->coverable=coverable;
    }
protected:
    int x;
    int y;
    int eatable;//判断可吃及可吃的类型
    bool coverable;//判断可否覆盖
    bool usable;//判断是否已经被使用
};

#endif // OBJECT_H
