#include "stillth.h"
#include "player.h"
bool stillth::eaten(){

}
bool stillth::covered(){

}
