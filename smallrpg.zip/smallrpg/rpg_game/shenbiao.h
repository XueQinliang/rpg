#ifndef SHENBIAO_H
#define SHENBIAO_H
#include "feibiao.h"
class shenbiao:public feibiao{
public:shenbiao(){used=false;}
    shenbiao(int x,int y);
    void show(QPainter &p,int x,int y);
    int get_sss(){
        return sss;
    }
    void start(){
        sss=1;
    }
protected:static int sss;//用来反映神镖现在状态的变量
    QImage a;
};

#endif // SHENBIAO_H
