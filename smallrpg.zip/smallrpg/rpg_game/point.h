#ifndef POINT_H
#define POINT_H
class point{
public:
    point(){}
    point(int x,int y):x(x),y(y){}
    point(point &p){
        this->x=p.x;
        this->y=p.y;
    }
    int getx(){return x;}
    int gety(){return y;}
private:
    int x,y;
};

#endif // POINT_H
