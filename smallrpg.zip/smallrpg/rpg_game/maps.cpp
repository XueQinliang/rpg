#include "maps.h"
#include <iostream>
int *maps::pair(char *str){//用来匹配字符串和数组指针的函数
    if(strcmp(str,"bucket")==0)return thing.bucket;
    if(strcmp(str,"stone1")==0)return thing.stone1;
    if(strcmp(str,"stone2")==0)return thing.stone2;
    if(strcmp(str,"tree1")==0)return thing.tree1;
    if(strcmp(str,"tree2")==0)return thing.tree2;
    if(strcmp(str,"tree3")==0)return thing.tree3;
    if(strcmp(str,"wood1")==0)return thing.wood1;
    if(strcmp(str,"wood2")==0)return thing.wood2;   
    if(strcmp(str,"trees")==0)return thing.trees;
    if(strcmp(str,"dici")==0)return thing.dici;
    if(strcmp(str,"fruit")==0)return thing.fruit;
    if(strcmp(str,"red")==0)return thing.red;
    if(strcmp(str,"blue")==0)return thing.blue;
}
bool maps::beset(int x, int y){//检验是否可被放置人物或物品
    if(th[x][y].getuse()==true||th[x][y+1].getuse()==true)
        return false;
    else return true;
}

void maps::setmap(int x,int y,int *p){
    th[x][y].sets(p[0],p[1],p[2],p[3]);
    for(int i=x;i<x+p[2];i++){
        for(int j=y;j<y+p[3];j++){
            th[i][j].set(p[4],p[5]);
            th[i][j].usable=true;
        }
    }
}
void maps::setmaps(){
        for(int i=0;i<14;i++){
            for(int j=0;j<12;j++){
                stillth thi;
                th[i][j]=thi;
            }
        }
        FILE *fp;
        if((fp=fopen("maps.txt","r"))==NULL){
            std::cout<<"hhh";
            return;
        }
        while(!feof(fp)){
            char whole[20];
            char nam[10];
            fgets(whole,20,fp);
            char *temp = strtok(whole," \n");
            int times=0;
            int x,y;
            while(temp!=NULL){
                times++;
                if(times==1)x=atoi(temp);
                if(times==2)y=atoi(temp);
                if(times==3){
                    strcpy(nam,temp);
                    times=0;
                }
                temp=strtok(NULL," \n");
            }
            setmap(x,y,pair(nam));
        }
        fclose(fp);
    }
void maps::show(QPainter &paint){
    for(int i=0;i<14;i++){
        for(int j=0;j<12;j++){
            if(th[i][j].getx()!=0||th[i][j].gety()!=0){
              th[i][j].show(paint,i,j);
           }
        }
    }
}
